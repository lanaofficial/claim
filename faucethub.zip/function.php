<?php
require_once __DIR__.'/lib/autoload.php';
use CloudflareBypass\RequestMethod\CFCurl;
use CloudflareBypass\RequestMethod\CFStream;
use CloudflareBypass\RequestMethod\CFStreamContext;
use CloudflareBypass\RequestMethod\Curl;
use CloudflareBypass\RequestMethod\StreamContext;
class Autoclaim
{
   public function getSplit($file){
       return file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
   }
   public function userAgent(){
       $file = $this->getSplit(__DIR__.'/text/user-agent.txt');
       return $file[rand(0, count($file)-1)];
   }
   public function webPage($url, $post=null){
      $curl = new CFCurl(array('cache' => true, 'max_retries' => 3));
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_AUTOREFERER, true);
      curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
      curl_setopt($ch, CURLOPT_USERAGENT, $this->userAgent);
      if(isset($post) && $post !==""){
         curl_setopt($ch, CURLOPT_POST, true);
         curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
         curl_setopt($ch, CURLOPT_HEADER,true);
         curl_setopt($ch, CURLOPT_HTTPHEADER,"Content-Type: application/x-www-form-urlencoded");
      }
      if(!curl_errno($ch)){
         $get['exec'] = $curl->exec($ch);
         $get['infourl'] = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);  
      }
      curl_close($ch);
      return $get;
   }
   public function proxy(){
      $get = $this->webPage('http://www.httptunnel.ge/ProxyListForFree.aspx');
      $one = explode('href="ProxyChecker.aspx?p=', $get);
      for($i=1; $i<=count($one[1]); $i++){
         $two = explode('" target="_new">', $one[$i]);
         $data = $two[0];
         $hasil =explode('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',$data);
         if(isset($$hasil[0]) && $hasil[0]!==""){
            $file = fopen(__DIR__.'/text/proxy.txt','a');
                    fwrite($file, "\r\n".$hasil[0]);
                    fclose($file);
         }
      }
      return $file;
   }
}