<?php
require __DIR__.'/lib/faucethub/faucethub.php';
require __DIR__.'/function.php';
require __DIR__.'/config.php';
$new = new Autoclaim();
$l = glob(__DIR__.'/text/apikey/*.txt');
foreach($l as $file){
   $ap = $new->getSplit($file);
   foreach($ap as $apikey){
      $cur = array('btc','eth','xmr','ltc','doge','bch','zec','dgb','btx','blk','dash','ppc','xpm','pot');
      foreach($cur as $cy){
         $fh = new Faucethub($apikey, strtoupper($cy));
         $bl = $fh->getBalance();
         if(isset($bl["status"]) && $bl["status"] == 200){
            $check = $fh->checkAddress($config['wallet_'.$cy], strtoupper($cy));
            if(isset($check["status"]) && $check["status"] == 200){
               $send = $fh->send($config['wallet_'.$cy], $bl["balance"]);
               if(isset($send["status"]) && $send["status"] == 200){
                  print($send["message"]."\n");
               }else{
                  print($send["message"]."\n");
               }
            }else{
               print($check["message"]."\n");
            }
         }else{
            print($bl["message"]."\n");
         }
      }
   }
}