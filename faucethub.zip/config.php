<?php
$config['wallet_btc'] = '';
$config['wallet_eth'] = '';
$config['wallet_xmr'] = '';
$config['wallet_ltc'] = '';
$config['wallet_doge'] = '';
$config['wallet_bch'] = '';
$config['wallet_zec'] = '';
$config['wallet_dgb'] = '';
$config['wallet_btx'] = '';
$config['wallet_blk'] = '';
$config['wallet_dash'] = '';
$config['wallet_ppc'] = '';
$config['wallet_xpm'] = '';
$config['wallet_pot'] = '';